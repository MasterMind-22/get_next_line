#ifndef GET_NEXT_LINE_H_
# define GET_NEXT_LINE_H_


#ifndef BUFFER_SIZE
# define BUFFER_SIZE 9

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

char *get_next_line(int fd);
