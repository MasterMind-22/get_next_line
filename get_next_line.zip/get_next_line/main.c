#include "get_next_line.h"

int main()
{
	char *s = ft_strjoin(NULL, NULL);
	printf("%s\n", s);
}
