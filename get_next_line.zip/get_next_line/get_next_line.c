#include "get_next_line.h"

char *get_next_line(int fd)
{
	char *save_line;
	char *read_line;
	int i;
	int read_int;

	i = 0;
	read_line = malloc((BUFFER_SIZE + 1) * sizeof(char));
	if (!read_line)
		return (NULL);
	while (read_line[i] != '\n' read_int)
	{
		read_int = read(fd, read_line, BUFFER_SIZE);
		if (read_int == 0)
			return (NULL);

	}
}
