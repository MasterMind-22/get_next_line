#include "get_next_line.h"

char *get_next_line(int fd)
{
	char *save_line;
	char *read_line;
	int i;
	int read_int;

	i = 0;
	read_int  = 1;
	read_line = malloc((BUFFER_SIZE + 1) * sizeof(char));
	if (!read_line)
		return (NULL);
	while (newline_found(read_line) && read_int)
	{
		read_int = read(fd, read_line, BUFFER_SIZE);
		if (read_int == -1)
		{
			break;
			return (NULL);
		}
		read_line[BUFFER_SIZE] = '\0';
		if (save_line == NULL)
			save_line = ft_strdup("\0");
		else
			save_line = ft_strjoin(save_line, read_line);
	}
	free(read_line);
	return (save_line);
}

int main()
{
	int fd = open("file", O_RDONLY);
	printf("%s", get_next_line(fd));
}
